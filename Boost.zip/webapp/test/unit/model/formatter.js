sap.ui.require(
	[
		"sap/support/boost/model/formatter"
	],
	function (Formatter) {
		"use strict";
		QUnit.module("formatter", {
		before: function(){
		
		},
		after: function(){
		
		},
		beforeEach: function() {
		
		},
		afterEach: function() {
		
		}
	});
	
	// QUnit.test("Should read 'Regions' and 'Teams' data after page initialized.", function(assert){
		
		
	// });
	}
);